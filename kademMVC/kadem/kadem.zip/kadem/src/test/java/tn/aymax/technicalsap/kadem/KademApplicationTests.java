package tn.aymax.technicalsap.kadem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KademApplicationTests {

    @Test
    void contextLoads() {
    }

}
