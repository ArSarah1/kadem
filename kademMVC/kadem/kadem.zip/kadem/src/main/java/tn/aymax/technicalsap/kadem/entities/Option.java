package tn.aymax.technicalsap.kadem.entities;

public enum Option {
    GAMIX, SE, SIM, NIDS

}
