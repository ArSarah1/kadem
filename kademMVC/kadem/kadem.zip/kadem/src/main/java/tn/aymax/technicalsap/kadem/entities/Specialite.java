package tn.aymax.technicalsap.kadem.entities;

public enum Specialite {

    IA , RESEAUX , CLOUD , SECURITE
}
