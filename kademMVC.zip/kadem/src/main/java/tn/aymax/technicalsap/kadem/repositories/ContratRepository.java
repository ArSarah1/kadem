package tn.aymax.technicalsap.kadem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.aymax.technicalsap.kadem.entities.Contrat;

public interface ContratRepository extends JpaRepository<Contrat,Integer> {
}
