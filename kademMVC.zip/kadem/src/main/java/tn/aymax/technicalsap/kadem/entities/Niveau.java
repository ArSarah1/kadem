package tn.aymax.technicalsap.kadem.entities;

public enum Niveau {
    JUNIOR , SENIROR , EXPERT
}

