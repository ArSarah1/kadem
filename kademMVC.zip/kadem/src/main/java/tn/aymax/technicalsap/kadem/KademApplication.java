package tn.aymax.technicalsap.kadem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KademApplication {

    public static void main(String[] args) {
        SpringApplication.run(KademApplication.class, args);
    }

}
