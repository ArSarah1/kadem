package tn.aymax.technicalsap.kadem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.aymax.technicalsap.kadem.entities.Department;

public interface DepartementRepository extends JpaRepository<Department, Integer> {
}
